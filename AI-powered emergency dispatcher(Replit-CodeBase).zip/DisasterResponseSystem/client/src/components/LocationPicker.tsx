import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin, Target, Navigation } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LocationPickerProps {
  onLocationSelect: (location: string, coordinates?: { lat: number; lng: number }) => void;
  initialLocation?: string;
}

export default function LocationPicker({ onLocationSelect, initialLocation = "" }: LocationPickerProps) {
  const [location, setLocation] = useState(initialLocation);
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const { toast } = useToast();

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Geolocation not supported",
        description: "Your browser doesn't support geolocation.",
        variant: "destructive",
      });
      return;
    }

    setIsGettingLocation(true);
    
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setCoordinates({ lat: latitude, lng: longitude });
        
        try {
          // Use reverse geocoding to get address
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`
          );
          const data = await response.json();
          
          if (data.display_name) {
            const address = data.display_name;
            setLocation(address);
            onLocationSelect(address, { lat: latitude, lng: longitude });
            toast({
              title: "Location detected",
              description: "Your current location has been set.",
            });
          } else {
            const coordinates = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
            setLocation(coordinates);
            onLocationSelect(coordinates, { lat: latitude, lng: longitude });
            toast({
              title: "Location detected",
              description: "Coordinates have been set.",
            });
          }
        } catch (error) {
          // Fallback to coordinates if reverse geocoding fails
          const coordinates = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
          setLocation(coordinates);
          onLocationSelect(coordinates, { lat: latitude, lng: longitude });
          toast({
            title: "Location detected",
            description: "Coordinates have been set.",
          });
        }
        
        setIsGettingLocation(false);
      },
      (error) => {
        setIsGettingLocation(false);
        let message = "Unable to get your location.";
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            message = "Location access denied. Please enable location permissions.";
            break;
          case error.POSITION_UNAVAILABLE:
            message = "Location information unavailable.";
            break;
          case error.TIMEOUT:
            message = "Location request timed out.";
            break;
        }
        
        toast({
          title: "Location Error",
          description: message,
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const handleLocationChange = (newLocation: string) => {
    setLocation(newLocation);
    onLocationSelect(newLocation, coordinates);
  };

  const searchLocation = async (query: string) => {
    if (!query.trim()) return;
    
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`
      );
      const data = await response.json();
      
      if (data.length > 0) {
        const result = data[0];
        const lat = parseFloat(result.lat);
        const lng = parseFloat(result.lon);
        
        setCoordinates({ lat, lng });
        setLocation(result.display_name);
        onLocationSelect(result.display_name, { lat, lng });
        
        toast({
          title: "Location found",
          description: "Location has been set from search.",
        });
      } else {
        toast({
          title: "Location not found",
          description: "Try a different search term.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Search failed",
        description: "Unable to search for location.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="location" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Location *
            </Label>
            <Input
              id="location"
              placeholder="Enter location or address"
              value={location}
              onChange={(e) => handleLocationChange(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  searchLocation(location);
                }
              }}
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={getCurrentLocation}
              disabled={isGettingLocation}
              className="flex-1"
            >
              <Target className="h-4 w-4 mr-2" />
              {isGettingLocation ? "Getting Location..." : "Use Current Location"}
            </Button>
            
            <Button
              type="button"
              variant="outline"
              onClick={() => searchLocation(location)}
              className="flex-1"
            >
              <Navigation className="h-4 w-4 mr-2" />
              Search Location
            </Button>
          </div>

          {coordinates && (
            <div className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>
                  Coordinates: {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
                </span>
              </div>
              <div className="mt-2">
                <a
                  href={`https://www.google.com/maps?q=${coordinates.lat},${coordinates.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  View on Google Maps
                </a>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}