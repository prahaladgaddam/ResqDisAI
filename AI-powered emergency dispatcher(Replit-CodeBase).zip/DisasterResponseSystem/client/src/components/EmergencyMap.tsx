import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { type EmergencyReport } from "@shared/schema";
import { Map, MapPin, ExternalLink, ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

interface EmergencyMapProps {
  reports: EmergencyReport[];
}

export default function EmergencyMap({ reports }: EmergencyMapProps) {
  const [selectedReport, setSelectedReport] = useState<EmergencyReport | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 40.7128, lng: -74.0060 }); // Default to NYC
  const [zoomLevel, setZoomLevel] = useState(10);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [mapOffset, setMapOffset] = useState({ x: 0, y: 0 });
  const mapContainerRef = useRef<HTMLDivElement>(null);

  // Calculate center based on reports with coordinates
  useEffect(() => {
    const reportsWithCoords = reports.filter(report => report.coordinates);
    if (reportsWithCoords.length > 0) {
      const avgLat = reportsWithCoords.reduce((sum, report) => sum + report.coordinates!.lat, 0) / reportsWithCoords.length;
      const avgLng = reportsWithCoords.reduce((sum, report) => sum + report.coordinates!.lng, 0) / reportsWithCoords.length;
      setMapCenter({ lat: avgLat, lng: avgLng });
      setZoomLevel(12); // Zoom in when we have actual locations
    }
  }, [reports]);

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "critical": return "bg-red-500 text-white";
      case "urgent": return "bg-orange-500 text-white";
      case "request": return "bg-yellow-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const formatUrgencyText = (urgency: string) => {
    switch (urgency) {
      case "critical": return "Critical / SOS";
      case "urgent": return "Urgent";
      case "request": return "Request";
      default: return urgency;
    }
  };

  // Utility functions for coordinate conversion
  const deg2rad = (deg: number) => deg * (Math.PI / 180);
  const rad2deg = (rad: number) => rad * (180 / Math.PI);

  const lngToTileX = (lng: number, zoom: number) => {
    return Math.floor((lng + 180) / 360 * Math.pow(2, zoom));
  };

  const latToTileY = (lat: number, zoom: number) => {
    return Math.floor((1 - Math.log(Math.tan(deg2rad(lat)) + 1 / Math.cos(deg2rad(lat))) / Math.PI) / 2 * Math.pow(2, zoom));
  };

  const tileXToLng = (x: number, zoom: number) => {
    return (x / Math.pow(2, zoom) * 360 - 180);
  };

  const tileYToLat = (y: number, zoom: number) => {
    const n = Math.PI - 2 * Math.PI * y / Math.pow(2, zoom);
    return rad2deg(Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))));
  };

  const coordsToPixels = (lat: number, lng: number, centerLat: number, centerLng: number, zoom: number, mapWidth: number, mapHeight: number) => {
    const tileSize = 256;
    const scale = Math.pow(2, zoom);
    
    const centerX = (centerLng + 180) / 360 * scale * tileSize;
    const centerY = (1 - Math.log(Math.tan(deg2rad(centerLat)) + 1 / Math.cos(deg2rad(centerLat))) / Math.PI) / 2 * scale * tileSize;
    
    const pointX = (lng + 180) / 360 * scale * tileSize;
    const pointY = (1 - Math.log(Math.tan(deg2rad(lat)) + 1 / Math.cos(deg2rad(lat))) / Math.PI) / 2 * scale * tileSize;
    
    return {
      x: mapWidth / 2 + (pointX - centerX) + mapOffset.x,
      y: mapHeight / 2 + (pointY - centerY) + mapOffset.y
    };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const deltaX = e.clientX - dragStart.x;
    const deltaY = e.clientY - dragStart.y;
    
    setMapOffset(prev => ({
      x: prev.x + deltaX,
      y: prev.y + deltaY
    }));
    
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 1, 18));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 1, 1));
  };

  const resetView = () => {
    setMapOffset({ x: 0, y: 0 });
    setZoomLevel(10);
    const reportsWithCoords = reports.filter(report => report.coordinates);
    if (reportsWithCoords.length > 0) {
      const avgLat = reportsWithCoords.reduce((sum, report) => sum + report.coordinates!.lat, 0) / reportsWithCoords.length;
      const avgLng = reportsWithCoords.reduce((sum, report) => sum + report.coordinates!.lng, 0) / reportsWithCoords.length;
      setMapCenter({ lat: avgLat, lng: avgLng });
    }
  };

  const reportsWithCoords = reports.filter(report => report.coordinates);
  const mapWidth = 600;
  const mapHeight = 400;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Map className="h-5 w-5" />
            Emergency Response Map
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleZoomIn}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleZoomOut}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={resetView}>
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {reportsWithCoords.length === 0 ? (
          <div className="h-96 bg-muted rounded-lg flex items-center justify-center border-2 border-dashed">
            <div className="text-center">
              <Map className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h5 className="text-lg font-semibold mb-2">No Location Data</h5>
              <p className="text-muted-foreground">
                Emergency reports with location coordinates will appear here.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Interactive Map */}
            <div 
              ref={mapContainerRef}
              className="relative bg-blue-50 rounded-lg overflow-hidden cursor-grab active:cursor-grabbing"
              style={{ height: mapHeight }}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              {/* OpenStreetMap tiles */}
              <div className="absolute inset-0">
                {(() => {
                  const centerX = lngToTileX(mapCenter.lng, zoomLevel);
                  const centerY = latToTileY(mapCenter.lat, zoomLevel);
                  const tilesX = Math.ceil(mapWidth / 256) + 2;
                  const tilesY = Math.ceil(mapHeight / 256) + 2;
                  const tiles = [];
                  
                  for (let x = -Math.floor(tilesX / 2); x <= Math.floor(tilesX / 2); x++) {
                    for (let y = -Math.floor(tilesY / 2); y <= Math.floor(tilesY / 2); y++) {
                      const tileX = centerX + x;
                      const tileY = centerY + y;
                      
                      if (tileX >= 0 && tileY >= 0 && tileX < Math.pow(2, zoomLevel) && tileY < Math.pow(2, zoomLevel)) {
                        const pixelX = (mapWidth / 2) + (x * 256) + mapOffset.x;
                        const pixelY = (mapHeight / 2) + (y * 256) + mapOffset.y;
                        
                        tiles.push(
                          <img
                            key={`${tileX}-${tileY}`}
                            src={`https://tile.openstreetmap.org/${zoomLevel}/${tileX}/${tileY}.png`}
                            alt="Map tile"
                            className="absolute"
                            style={{
                              left: pixelX,
                              top: pixelY,
                              width: 256,
                              height: 256
                            }}
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        );
                      }
                    }
                  }
                  
                  return tiles;
                })()}
              </div>
              
              {/* Emergency markers overlay */}
              <svg width={mapWidth} height={mapHeight} className="absolute inset-0 pointer-events-none">
                {reportsWithCoords.map((report) => {
                  const { x, y } = coordsToPixels(
                    report.coordinates!.lat, 
                    report.coordinates!.lng, 
                    mapCenter.lat, 
                    mapCenter.lng, 
                    zoomLevel, 
                    mapWidth, 
                    mapHeight
                  );
                  const isSelected = selectedReport?.id === report.id;
                  
                  if (x < -50 || x > mapWidth + 50 || y < -50 || y > mapHeight + 50) {
                    return null; // Don't render markers outside visible area
                  }
                  
                  return (
                    <g key={report.id} className="pointer-events-auto">
                      <circle
                        cx={x}
                        cy={y}
                        r={isSelected ? 15 : 10}
                        fill={report.urgencyLevel === 'critical' ? '#ef4444' : 
                              report.urgencyLevel === 'urgent' ? '#f97316' : '#eab308'}
                        stroke={isSelected ? '#1f2937' : '#ffffff'}
                        strokeWidth={isSelected ? 3 : 2}
                        className="cursor-pointer transition-all hover:r-12 drop-shadow-lg"
                        onClick={() => setSelectedReport(report)}
                      />
                      <text
                        x={x}
                        y={y + 25}
                        textAnchor="middle"
                        className="text-xs font-bold fill-gray-800 drop-shadow-sm pointer-events-none"
                        style={{ fontSize: '11px' }}
                      >
                        #{report.id}
                      </text>
                    </g>
                  );
                })}
              </svg>
              
              {/* Map info */}
              <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-xs text-gray-600">
                Zoom: {zoomLevel} | © OpenStreetMap contributors
              </div>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span>Critical</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                <span>Urgent</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span>Request</span>
              </div>
              <div className="text-muted-foreground">
                Drag to pan • Scroll to zoom • Click markers for details
              </div>
            </div>

            {/* Selected report details */}
            {selectedReport && (
              <div className="bg-muted/50 p-4 rounded-lg border">
                <div className="flex justify-between items-start mb-2">
                  <h6 className="font-semibold">Emergency Report #{selectedReport.id}</h6>
                  <Badge className={getUrgencyColor(selectedReport.urgencyLevel)}>
                    {formatUrgencyText(selectedReport.urgencyLevel)}
                  </Badge>
                </div>
                <div className="space-y-2 text-sm">
                  <div>
                    <strong>Reporter:</strong> {selectedReport.reporterName || "Anonymous"}
                  </div>
                  <div>
                    <strong>Location:</strong> {selectedReport.location}
                  </div>
                  <div>
                    <strong>People:</strong> {selectedReport.numberOfPeople}
                  </div>
                  {selectedReport.additionalNotes && (
                    <div>
                      <strong>Notes:</strong> {selectedReport.additionalNotes}
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const { lat, lng } = selectedReport.coordinates!;
                        window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
                      }}
                    >
                      <ExternalLink className="h-3 w-3 mr-1" />
                      View on Google Maps
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedReport(null)}
                    >
                      Close
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Map statistics */}
            <div className="text-sm text-muted-foreground">
              Showing {reportsWithCoords.length} of {reports.length} emergency reports with location data
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}