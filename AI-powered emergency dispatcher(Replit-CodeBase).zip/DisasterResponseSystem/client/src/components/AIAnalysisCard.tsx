import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Clock, AlertTriangle, Users } from "lucide-react";
import { type EmergencyReport } from "@shared/schema";

interface AIAnalysisCardProps {
  report: EmergencyReport;
}

export default function AIAnalysisCard({ report }: AIAnalysisCardProps) {
  const { aiAnalysis } = report;
  
  if (!aiAnalysis) {
    return (
      <Card className="border-muted">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Brain className="h-4 w-4 text-muted-foreground" />
            AI Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Analysis not available
        </CardContent>
      </Card>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-500 text-white";
      case "high": return "bg-orange-500 text-white";
      case "medium": return "bg-yellow-500 text-white";
      case "low": return "bg-green-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "medical": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      case "fire": return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-100";
      case "rescue": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";
      case "security": return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100";
    }
  };

  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-4 w-4 text-blue-500" />
            <span className="text-sm">AI Analysis</span>
          </div>
          <Badge className={getSeverityColor(aiAnalysis.severity)}>
            {aiAnalysis.severity.toUpperCase()}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className={getCategoryColor(aiAnalysis.category)}>
            {aiAnalysis.category.toUpperCase()}
          </Badge>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="h-3 w-3" />
            {aiAnalysis.estimatedResponseTime}
          </div>
        </div>

        {aiAnalysis.resourcesNeeded.length > 0 && (
          <div>
            <h6 className="text-xs font-semibold mb-1 text-muted-foreground">RESOURCES NEEDED</h6>
            <div className="flex flex-wrap gap-1">
              {aiAnalysis.resourcesNeeded.map((resource, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {resource}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {aiAnalysis.keyInsights.length > 0 && (
          <div>
            <h6 className="text-xs font-semibold mb-1 text-muted-foreground">KEY INSIGHTS</h6>
            <ul className="space-y-1">
              {aiAnalysis.keyInsights.map((insight, index) => (
                <li key={index} className="text-xs flex items-start gap-2">
                  <div className="w-1 h-1 bg-blue-500 rounded-full mt-1.5 flex-shrink-0" />
                  {insight}
                </li>
              ))}
            </ul>
          </div>
        )}

        {aiAnalysis.riskFactors.length > 0 && (
          <div>
            <h6 className="text-xs font-semibold mb-1 text-muted-foreground flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" />
              RISK FACTORS
            </h6>
            <ul className="space-y-1">
              {aiAnalysis.riskFactors.map((risk, index) => (
                <li key={index} className="text-xs flex items-start gap-2 text-orange-600 dark:text-orange-400">
                  <div className="w-1 h-1 bg-orange-500 rounded-full mt-1.5 flex-shrink-0" />
                  {risk}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}