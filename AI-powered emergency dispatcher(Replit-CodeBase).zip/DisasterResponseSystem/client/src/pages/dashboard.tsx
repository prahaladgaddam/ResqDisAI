import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type EmergencyReport } from "@shared/schema";
import EmergencyMap from "@/components/EmergencyMap";
import AIAnalysisCard from "@/components/AIAnalysisCard";
import { 
  ClipboardList, 
  AlertTriangle, 
  Truck, 
  CheckCircle, 
  Map, 
  Search, 
  RefreshCw,
  Phone,
  MapPin,
  Clock,
  ChevronDown
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [urgencyFilter, setUrgencyFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: reports = [], isLoading: reportsLoading } = useQuery({
    queryKey: ["/api/emergency-reports"],
    queryFn: async () => {
      const response = await fetch("/api/emergency-reports");
      return response.json();
    },
  });

  const { data: stats = { total: 0, critical: 0, dispatched: 0, resolved: 0 } } = useQuery({
    queryKey: ["/api/emergency-reports/stats"],
    queryFn: async () => {
      const response = await fetch("/api/emergency-reports/stats");
      return response.json();
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest("PATCH", `/api/emergency-reports/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Status Updated",
        description: "Emergency report status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "critical": return "bg-red-500 text-white";
      case "urgent": return "bg-orange-500 text-white";
      case "request": return "bg-yellow-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new": return "bg-red-500 text-white";
      case "acknowledged": return "bg-blue-500 text-white";
      case "dispatched": return "bg-yellow-500 text-white";
      case "resolved": return "bg-green-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const formatUrgencyText = (urgency: string) => {
    switch (urgency) {
      case "critical": return "Critical / SOS";
      case "urgent": return "Urgent";
      case "request": return "Request";
      default: return urgency;
    }
  };

  const formatStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const filteredReports = reports.filter((report: EmergencyReport) => {
    const matchesSearch = !searchTerm || 
      report.reporterName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.additionalNotes?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesUrgency = urgencyFilter === "all" || report.urgencyLevel === urgencyFilter;
    const matchesStatus = statusFilter === "all" || report.status === statusFilter;
    
    return matchesSearch && matchesUrgency && matchesStatus;
  });

  const formatRequestTypes = (types: string[]) => {
    const typeLabels: { [key: string]: string } = {
      evacuation: "Evacuation / Rescue",
      medical: "Medical Emergency",
      foodWater: "Food & Water",
      shelter: "Shelter",
      other: "Other"
    };
    
    return types.map(type => typeLabels[type] || type);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports"] });
    queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports/stats"] });
  };

  return (
    <div className="container-fluid px-4 py-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="flex flex-col items-center justify-center p-6">
            <ClipboardList className="h-8 w-8 text-primary mb-2" />
            <div className="text-3xl font-bold text-primary">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Total Requests</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="flex flex-col items-center justify-center p-6">
            <AlertTriangle className="h-8 w-8 text-red-500 mb-2" />
            <div className="text-3xl font-bold text-red-500">{stats.critical}</div>
            <div className="text-sm text-muted-foreground">Critical</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="flex flex-col items-center justify-center p-6">
            <Truck className="h-8 w-8 text-yellow-500 mb-2" />
            <div className="text-3xl font-bold text-yellow-500">{stats.dispatched}</div>
            <div className="text-sm text-muted-foreground">Dispatched</div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="flex flex-col items-center justify-center p-6">
            <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
            <div className="text-3xl font-bold text-green-500">{stats.resolved}</div>
            <div className="text-sm text-muted-foreground">Resolved</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Emergency Response Map */}
        <div className="lg:col-span-2">
          <EmergencyMap reports={reports} />
        </div>

        {/* Live Requests Panel */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  Live Requests
                </CardTitle>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleRefresh}
                  disabled={reportsLoading}
                >
                  <RefreshCw className={`h-4 w-4 mr-1 ${reportsLoading ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {/* Search and Filters */}
              <div className="p-4 border-b bg-muted/30">
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search requests..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Select value={urgencyFilter} onValueChange={setUrgencyFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Urgency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Urgency</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                        <SelectItem value="request">Request</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="acknowledged">Acknowledged</SelectItem>
                        <SelectItem value="dispatched">Dispatched</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Request List */}
              <div className="max-h-96 overflow-y-auto">
                {reportsLoading ? (
                  <div className="p-4 text-center text-muted-foreground">
                    Loading requests...
                  </div>
                ) : filteredReports.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">
                    No requests found matching your criteria.
                  </div>
                ) : (
                  filteredReports.map((report: EmergencyReport) => (
                    <div key={report.id} className="p-4 border-b hover:bg-muted/50 transition-colors">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex gap-2">
                          <Badge className={getUrgencyColor(report.urgencyLevel)}>
                            {formatUrgencyText(report.urgencyLevel)}
                          </Badge>
                          <Badge className={getStatusColor(report.status)}>
                            {formatStatusText(report.status)}
                          </Badge>
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatDistanceToNow(new Date(report.createdAt), { addSuffix: true })}
                        </div>
                      </div>
                      
                      <h6 className="font-medium mb-1">
                        {report.reporterName || "Anonymous Reporter"}
                      </h6>
                      
                      <div className="flex items-center text-sm text-muted-foreground mb-2">
                        <MapPin className="h-3 w-3 mr-1" />
                        {report.location}
                      </div>
                      
                      <div className="flex flex-wrap gap-1 mb-2">
                        {formatRequestTypes(report.requestTypes).map((type, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                      
                      {report.additionalNotes && (
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {report.additionalNotes}
                        </p>
                      )}
                      
                      {/* AI Analysis */}
                      {report.aiAnalysis && (
                        <div className="mb-3">
                          <AIAnalysisCard report={report} />
                        </div>
                      )}
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Phone className="h-3 w-3 mr-1" />
                          Call
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button 
                              variant="default" 
                              size="sm"
                              className={getStatusColor(report.status)}
                            >
                              {formatStatusText(report.status)}
                              <ChevronDown className="h-3 w-3 ml-1" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            {["new", "acknowledged", "dispatched", "resolved"].map((status) => (
                              <DropdownMenuItem
                                key={status}
                                onClick={() => updateStatusMutation.mutate({ id: report.id, status })}
                                disabled={updateStatusMutation.isPending}
                              >
                                {formatStatusText(status)}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
