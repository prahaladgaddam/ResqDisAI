import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertEmergencyReportSchema, type InsertEmergencyReport } from "@shared/schema";
import LocationPicker from "@/components/LocationPicker";
import { z } from "zod";
import { Shield, User, MapPin, Users, Phone, FileText, Send } from "lucide-react";

const formSchema = insertEmergencyReportSchema.extend({
  requestTypes: z.array(z.string()).min(1, "Please select at least one request type"),
});

type FormData = z.infer<typeof formSchema>;

export default function EmergencyForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedRequestTypes, setSelectedRequestTypes] = useState<string[]>([]);
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      reporterName: "",
      location: "",
      numberOfPeople: 1,
      urgencyLevel: "",
      requestTypes: [],
      additionalNotes: "",
    },
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: InsertEmergencyReport) => {
      const reportData = {
        ...data,
        coordinates: coordinates || undefined,
      };
      const response = await apiRequest("POST", "/api/emergency-reports", reportData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Emergency report submitted successfully!",
      });
      form.reset();
      setSelectedRequestTypes([]);
      setCoordinates(null);
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit emergency report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRequestTypeChange = (requestType: string, checked: boolean) => {
    const updatedTypes = checked
      ? [...selectedRequestTypes, requestType]
      : selectedRequestTypes.filter(type => type !== requestType);
    
    setSelectedRequestTypes(updatedTypes);
    form.setValue("requestTypes", updatedTypes);
  };

  const handleLocationSelect = (location: string, coords?: { lat: number; lng: number }) => {
    form.setValue("location", location);
    setCoordinates(coords || null);
  };

  const onSubmit = (data: FormData) => {
    createReportMutation.mutate(data);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader className="bg-primary text-primary-foreground">
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6" />
              <div>
                <h1 className="text-2xl font-bold">Manual Entry Portal</h1>
                <p className="text-sm opacity-90">Fast data entry for calls & messages</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Reporter Name */}
              <div className="space-y-2">
                <Label htmlFor="reporterName" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Reporter Name (Optional)
                </Label>
                <Input
                  id="reporterName"
                  placeholder="Name of person calling/texting"
                  {...form.register("reporterName")}
                />
              </div>

              {/* Location */}
              <div className="space-y-2">
                <LocationPicker
                  onLocationSelect={handleLocationSelect}
                  initialLocation={form.watch("location")}
                />
                {form.formState.errors.location && (
                  <p className="text-sm text-destructive">{form.formState.errors.location.message}</p>
                )}
              </div>

              {/* Number of People */}
              <div className="space-y-2">
                <Label htmlFor="numberOfPeople" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Number of People *
                </Label>
                <Input
                  id="numberOfPeople"
                  type="number"
                  min="1"
                  {...form.register("numberOfPeople", { valueAsNumber: true })}
                />
                {form.formState.errors.numberOfPeople && (
                  <p className="text-sm text-destructive">{form.formState.errors.numberOfPeople.message}</p>
                )}
              </div>

              {/* Urgency Level */}
              <div className="space-y-4">
                <Label className="text-base font-semibold">Urgency Level *</Label>
                <RadioGroup
                  value={form.watch("urgencyLevel")}
                  onValueChange={(value) => form.setValue("urgencyLevel", value)}
                >
                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50">
                    <RadioGroupItem value="critical" id="critical" />
                    <Label htmlFor="critical" className="flex items-center gap-3 cursor-pointer flex-1">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div>
                        <div className="font-semibold">Critical / SOS</div>
                        <div className="text-sm text-muted-foreground">Life-threatening situation</div>
                      </div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50">
                    <RadioGroupItem value="urgent" id="urgent" />
                    <Label htmlFor="urgent" className="flex items-center gap-3 cursor-pointer flex-1">
                      <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                      <div>
                        <div className="font-semibold">Urgent</div>
                        <div className="text-sm text-muted-foreground">Needs rescue/evacuation, serious injury</div>
                      </div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50">
                    <RadioGroupItem value="request" id="request" />
                    <Label htmlFor="request" className="flex items-center gap-3 cursor-pointer flex-1">
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <div>
                        <div className="font-semibold">Request</div>
                        <div className="text-sm text-muted-foreground">Needs supplies like food, water, first-aid</div>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
                {form.formState.errors.urgencyLevel && (
                  <p className="text-sm text-destructive">{form.formState.errors.urgencyLevel.message}</p>
                )}
              </div>

              {/* Request Types */}
              <div className="space-y-4">
                <Label className="text-base font-semibold">Request Type * (Select all that apply)</Label>
                <div className="space-y-3">
                  {[
                    { value: "evacuation", label: "Evacuation / Rescue", icon: "🏃" },
                    { value: "medical", label: "Medical Emergency", icon: "🚑" },
                    { value: "foodWater", label: "Food & Water", icon: "🍽️" },
                    { value: "shelter", label: "Shelter", icon: "🏠" },
                    { value: "other", label: "Other", icon: "⚪" },
                  ].map((type) => (
                    <div key={type.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={type.value}
                        checked={selectedRequestTypes.includes(type.value)}
                        onCheckedChange={(checked) => handleRequestTypeChange(type.value, checked as boolean)}
                      />
                      <Label htmlFor={type.value} className="flex items-center gap-2 cursor-pointer">
                        <span>{type.icon}</span>
                        {type.label}
                      </Label>
                    </div>
                  ))}
                </div>
                {form.formState.errors.requestTypes && (
                  <p className="text-sm text-destructive">{form.formState.errors.requestTypes.message}</p>
                )}
              </div>

              {/* Additional Notes */}
              <div className="space-y-2">
                <Label htmlFor="additionalNotes" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Additional Notes
                </Label>
                <Textarea
                  id="additionalNotes"
                  placeholder="Any extra details from the conversation..."
                  rows={4}
                  {...form.register("additionalNotes")}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                disabled={createReportMutation.isPending}
              >
                {createReportMutation.isPending ? (
                  "Submitting..."
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Submit Entry
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
