import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEmergencyReportSchema, updateEmergencyReportSchema } from "@shared/schema";
import { analyzeEmergencyReport } from "./ai-analysis";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Emergency reports endpoints
  app.post("/api/emergency-reports", async (req, res) => {
    try {
      const reportData = insertEmergencyReportSchema.parse(req.body);
      
      // Generate AI analysis
      const aiAnalysis = await analyzeEmergencyReport(
        reportData.additionalNotes || "",
        reportData.urgencyLevel,
        reportData.numberOfPeople,
        Array.isArray(reportData.requestTypes) ? reportData.requestTypes : []
      );
      
      const reportWithAI = {
        ...reportData,
        aiAnalysis
      };
      
      const report = await storage.createEmergencyReport(reportWithAI);
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create emergency report" });
      }
    }
  });

  app.get("/api/emergency-reports", async (req, res) => {
    try {
      const reports = await storage.getAllEmergencyReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch emergency reports" });
    }
  });

  app.get("/api/emergency-reports/stats", async (req, res) => {
    try {
      const stats = await storage.getEmergencyReportStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.patch("/api/emergency-reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = updateEmergencyReportSchema.parse(req.body);
      
      const report = await storage.updateEmergencyReportStatus(id, updateData.status);
      if (!report) {
        res.status(404).json({ message: "Emergency report not found" });
        return;
      }
      
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update emergency report" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
