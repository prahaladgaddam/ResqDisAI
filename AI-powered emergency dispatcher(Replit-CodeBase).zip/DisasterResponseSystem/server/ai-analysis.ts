import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface AIAnalysis {
  category: string;
  severity: "low" | "medium" | "high" | "critical";
  resourcesNeeded: string[];
  keyInsights: string[];
  estimatedResponseTime: string;
  riskFactors: string[];
}

export async function analyzeEmergencyReport(
  reportText: string,
  urgencyLevel: string,
  numberOfPeople: number,
  requestTypes: string[]
): Promise<AIAnalysis> {
  try {
    const prompt = `Analyze this emergency report and provide structured insights:

Report Details:
- Text: "${reportText}"
- Urgency: ${urgencyLevel}
- People involved: ${numberOfPeople}
- Request types: ${requestTypes.join(", ")}

Provide analysis in this JSON format:
{
  "category": "medical/fire/rescue/security/infrastructure/other",
  "severity": "low/medium/high/critical",
  "resourcesNeeded": ["ambulance", "fire truck", "police", "rescue team", "medical supplies"],
  "keyInsights": ["brief actionable insight 1", "brief actionable insight 2"],
  "estimatedResponseTime": "5-10 minutes",
  "riskFactors": ["potential risk 1", "potential risk 2"]
}

Keep insights concise and actionable for emergency dispatchers.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an emergency dispatch AI assistant. Analyze emergency reports and provide structured, actionable insights for emergency responders."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 300,
      temperature: 0.1
    });

    const analysis = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      category: analysis.category || "other",
      severity: analysis.severity || "medium",
      resourcesNeeded: analysis.resourcesNeeded || [],
      keyInsights: analysis.keyInsights || [],
      estimatedResponseTime: analysis.estimatedResponseTime || "10-15 minutes",
      riskFactors: analysis.riskFactors || []
    };

  } catch (error) {
    console.error('AI Analysis failed:', error);
    
    // Fallback analysis based on urgency and request types
    return {
      category: getBasicCategory(requestTypes),
      severity: urgencyLevel === "critical" ? "critical" : urgencyLevel === "urgent" ? "high" : "medium",
      resourcesNeeded: getBasicResources(requestTypes),
      keyInsights: [`${numberOfPeople} people affected`, `${urgencyLevel} urgency level`],
      estimatedResponseTime: urgencyLevel === "critical" ? "5-10 minutes" : "10-20 minutes",
      riskFactors: numberOfPeople > 1 ? ["Multiple people involved"] : []
    };
  }
}

function getBasicCategory(requestTypes: string[]): string {
  if (requestTypes.includes("medical")) return "medical";
  if (requestTypes.includes("fire")) return "fire";
  if (requestTypes.includes("rescue")) return "rescue";
  if (requestTypes.includes("security")) return "security";
  return "other";
}

function getBasicResources(requestTypes: string[]): string[] {
  const resources: string[] = [];
  if (requestTypes.includes("medical")) resources.push("ambulance", "medical supplies");
  if (requestTypes.includes("fire")) resources.push("fire truck", "fire crew");
  if (requestTypes.includes("rescue")) resources.push("rescue team", "equipment");
  if (requestTypes.includes("security")) resources.push("police");
  return resources;
}