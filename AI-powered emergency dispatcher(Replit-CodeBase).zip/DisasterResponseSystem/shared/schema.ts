import { pgTable, text, serial, integer, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const emergencyReports = pgTable("emergency_reports", {
  id: serial("id").primaryKey(),
  reporterName: text("reporter_name"),
  location: text("location").notNull(),
  coordinates: json("coordinates").$type<{ lat: number; lng: number }>(),
  numberOfPeople: integer("number_of_people").notNull(),
  urgencyLevel: text("urgency_level").notNull(), // 'critical', 'urgent', 'request'
  requestTypes: json("request_types").$type<string[]>().notNull(),
  additionalNotes: text("additional_notes"),
  status: text("status").notNull().default("new"), // 'new', 'acknowledged', 'dispatched', 'resolved'
  aiAnalysis: json("ai_analysis").$type<{
    category: string;
    severity: "low" | "medium" | "high" | "critical";
    resourcesNeeded: string[];
    keyInsights: string[];
    estimatedResponseTime: string;
    riskFactors: string[];
  }>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertEmergencyReportSchema = createInsertSchema(emergencyReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateEmergencyReportSchema = z.object({
  status: z.enum(["new", "acknowledged", "dispatched", "resolved"]),
});

export type InsertEmergencyReport = z.infer<typeof insertEmergencyReportSchema>;
export type EmergencyReport = typeof emergencyReports.$inferSelect;
export type UpdateEmergencyReport = z.infer<typeof updateEmergencyReportSchema>;

// Keep existing user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
